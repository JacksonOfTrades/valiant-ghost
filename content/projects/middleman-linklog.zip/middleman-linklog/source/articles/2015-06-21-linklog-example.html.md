---
title: <a href="https://www.youtube.com/watch?v=KC_KUKlKouQ">A Linklog example</a>
date: 2015-06-21
tags: 
pagetitle: A Linklogging example
---

So, right here we have an example of a linklog and all its glory, the title links out, how crazy is that?
